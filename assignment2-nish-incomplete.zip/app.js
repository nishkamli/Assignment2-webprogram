var express = require('express');
var path = require('path');
var app = express();
const fs = require('fs');

const exphbs = require('express-handlebars');

const port = 3000;
app.use(express.static(path.join(__dirname, 'public')));
app.engine('.hbs', exphbs({ extname: '.hbs' }));

app.set('view engine', 'hbs');

let Data = null;

fs.readFile(path.join(__dirname, 'CarSales.json'), 'utf-8', (err, data) => {
    if (err) {
        console.error('Error loading JSON data:', err);
        process.exit(1); // Terminate the process with a non-zero exit code
    }
    try {
        Data = JSON.parse(data);
        console.log('JSON data is loaded and ready!');
        
        app.listen(port, () => {
            console.log(`Server running on http://localhost:${port}`);
        });

    } catch (parseErr) {
        console.error('Error parsing JSON data:', parseErr);
        process.exit(1); // Terminate the process with a non-zero exit code
    }
});
app.get('/', function(req, res) {
  res.render('index', { title: 'Express' });
});
app.get('/data', (req, res) => {
    if (!Data) {
        return res.render('error', { title: 'Error', message: 'Error loading JSON data.' });
    }
    res.render('alldata', { data: Data });
});

app.get('/users', function(req, res) {
  res.send('respond with a resource');
});
app.get('*', function(req, res) {
  res.render('error', { title: 'Error', message:'Wrong Route' });
});
